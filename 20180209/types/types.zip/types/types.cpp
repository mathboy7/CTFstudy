#include<iostream>
#include<string>
#include<vector>
#include<signal.h>
#include<unistd.h>

using namespace std;

class Type_P{
    protected:
        string type_name;
    public:
        Type_P() : type_name(string()){}
        Type_P(string &tmp) : type_name(tmp) {}
        Type_P(Type_P &tmp) : type_name(tmp.get_type()) {}

        string& get_type(){
            return type_name;
        }
        void set_val(const char *name){
            type_name = name;
        }

        ~Type_P(){
            type_name.~string();
        }

};

template <class T>
class Type : public Type_P{
    private:
        T value;
    public:
        Type() : value(T()) {}
        Type(T value, string tname) : value(value), Type_P::Type_P(tname){}
        Type(Type &tmp) : value(tmp.get_val()), Type_P::Type_P(tmp.get_type()) {}

        T& get_val(){
            return value;
        }

        void val_init(){
            if(value < 0xdeadbeef)
                value = T();
            type_name = string();
        }

        void set_val(){
            cin.ignore();
            cin >> value;
        }
        ~Type() {}

};

template<>
class Type<string> : public Type_P{
    private:
        string value;
    public:
        Type() : value(string()) {}
        Type(string value, string tname) : value(value), Type_P::Type_P(tname){}
        Type(Type &tmp) : value(tmp.get_val()), Type_P::Type_P(tmp.get_type()) {}

        string& get_val(){
            return value;
        }

        void set_val(){
            cin.ignore();
            getline(cin, value);
        }

        void val_init(){
            value.clear();
            type_name = string();
        }

        ~Type(){
            value.~string();
        }
};

vector<Type_P*> type_list;


void alarm_handler(int signum){
    cout << "timeout!!" << endl;
    exit(1);
}

void Welcome(){
    cout << "\n\x1b[93mWelcome to types world!\x1b[0m" << endl;
}

void init(){
    setvbuf(stdout ,0 ,2 ,0);
    setvbuf(stdin, 0, 2, 0);

    signal(SIGALRM, alarm_handler);
    alarm(120);

}

int menu(){
    int choice;
    cout << "\n1. Add Type\n";
    cout << "2. View Type\n";
    cout << "3. Edit Type\n";
    cout << "4. Delete Type\n";
    cout << "5. Exit\n";
    cout << ">>> ";
    cin >> choice;
    return choice;
}

int Add_Type_menu(){
    int choice;
    cout << "\nSelect Type\n";
    cout << "1. Int\n";
    cout << "2. Float\n";
    cout << "3. String\n";
    cout << "4. back\n";
    cout << ">>> ";
    cin >>choice;
    return  choice;
}

void Int_add(){
    int64_t tmp;
    string tname("int");
    cout << "Input : ";
    cin >> tmp;

    Type<int64_t> *tmp2(new Type<int64_t>(tmp, tname));
    type_list.push_back(tmp2);
    
}

void Float_add(){
    double tmp;
    string tname("float");
    cout << "Input : ";
    cin >> tmp;

    Type<double> *tmp2(new Type<double>(tmp, tname));
    type_list.push_back(tmp2);
}

void String_add(){
    string tmp;
    string tname("string");
    cout << "Input : ";
    cin >> tmp;

    Type<string> *tmp2(new Type<string>(tmp, tname));
    type_list.push_back(tmp2);
}

void Add_Type(){
    while(1){
        switch(Add_Type_menu()){
            case 1:
                Int_add();
                break;
            case 2:
                Float_add();
                break;
            case 3:
                String_add();
                break;
            case 4:
                return ;
            default:
                break;
        }
    }
}

void Edit(){
    unsigned idx;
    unsigned choice;
    string name;
    cout << "index : ";
    cin >> idx;

    if(idx >= type_list.size() || type_list.size() == 0){
        cout << "Nop!!" << endl;
        return ;
    }
    cout << "Input : ";
    if("int" == type_list[idx]->get_type()){
        type_list[idx]->set_val("int");
        ((Type<int64_t>*)type_list[idx])->set_val();
    }
    else if("float" == type_list[idx] -> get_type()){
        type_list[idx]->set_val("float");
        ((Type<double>*)type_list[idx])->set_val();
    }
    else{
        type_list[idx]->set_val("string");
        ((Type<string>*)type_list[idx])->set_val();
    }
}

void View(){
    unsigned idx;

    cout << "index : ";
    cin >> idx;

    if(idx >= type_list.size() || type_list.size() == 0){
        cout << "Nop!! " << endl;
        return ;
    }

    if("string" == type_list[idx]->get_type()){
        type_list[idx]->set_val("string");
        cout << "\nvalue : " << ((Type<string>*)type_list[idx])->get_val() << endl;
    }
    else if("float" == type_list[idx] -> get_type()){
        type_list[idx]->set_val("float");
        cout << "\nvalue : " << ((Type<double>*)type_list[idx])->get_val() << endl;
    }
    else{
        type_list[idx]->set_val("int");
        cout << "\nvalue : " << ((Type<int64_t>*)type_list[idx])-> get_val() << endl;
    }
}

int Delete_menu(){
    int choice;
    cout << "1. Init\n";
    cout << "2. Delete\n";
    cout << ">>> ";
    cin >> choice;

    return choice;
}

void type_init(unsigned idx){
    if(type_list[idx]->get_type() == "int")
        ((Type<int64_t>*)type_list[idx])->val_init();
    else if(type_list[idx]->get_type() == "float")
        ((Type<double>*)type_list[idx])->val_init();
    else
        ((Type<string>*)type_list[idx])->val_init();
}

void Delete(){
    unsigned idx;
    unsigned choice;

    cout << "index : ";
    cin >> idx;

    if(idx >= type_list.size() || type_list.size() == 0){
        cout << "Nop!! " << endl;
        return ;
    }
    switch(Delete_menu()){
        case 1:
            type_init(idx);
            break;
        case 2:
            delete type_list[idx];
            type_list.erase(type_list.begin() + idx);
            break;
        default:
            break;
    }
}

int main(){
    init();
    Welcome();
    while(1){
        switch(menu()){
            case 1:
                Add_Type();
                break;
            case 2:
                View();
                break;
            case 3:
                Edit();
                break;
            case 4:
                Delete();
                break;
            case 5:
                cout << "Bye~~~" << endl;
                return 0;
            default:
                break;

        }
    }
    
}